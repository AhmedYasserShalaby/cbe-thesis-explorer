# CBE Thesis Replication Package

Companion to *Does Central Bank Communication Improve Stock-Market Return
Forecasts? Evidence from Egyptian Banks and Real Estate Sectors.*

## Reproduce the saved results

Extract the ZIP and put `Thesis_Data.xlsx` beside `Thesis.ipynb`. In a Python
environment, install the package and run the workbook checks from this folder.

```sh
python -m pip install -e .
python -m thesis_kit verify --excel
python -m thesis_kit diagnostics --excel
python -m thesis_kit followup
```

Open `Thesis.ipynb` in Jupyter with the same Python environment. It shows the
saved forecasts, paired comparisons, sector contrasts, audit controls and
the 24 September 2026 worked example. The workbook is a separate download.

The full workspace supplies the original derived inputs and archived results
for the Chapter 4 tables, training, and the workspace tests. Text refits require
a Gensim backend that passes the package's exact −1 dot-product check.
[Upstream Gensim patch](https://github.com/piskvorky/gensim/pull/3668)
