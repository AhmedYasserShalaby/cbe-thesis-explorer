# CBE Thesis Replication Package (`thesis_kit`)

Unified Python package and clean replication notebook for:
*Does Central Bank Communication Improve Stock-Market Return Forecasts? Evidence from Egyptian Banks and Real Estate Sectors.*

## Contents
- `thesis_kit/` — data loaders, Word2Vec/PCA features, chronological expanding-window models, metrics, paired bootstrap & direct sector contrasts, Ridge gain-vs-zero decomposition, Chapter 4 tables, and 21 Nov 2026 same-estimator audit controls.
- `Thesis.ipynb` — executed clean replication notebook (runs in full workspace mode or standalone with `Thesis_Data.xlsx` beside it).
- `tests/test_thesis_kit.py` — automated verification tests.
- `pyproject.toml` — package metadata and `thesis` CLI entry point (`verify`, `tables`, `diagnostics`, `followup`, `train`).

## Quick Start
```bash
pip install -e .
thesis verify --excel Thesis_Data.xlsx
thesis diagnostics --excel Thesis_Data.xlsx
thesis followup
```
