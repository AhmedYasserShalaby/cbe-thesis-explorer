# CBE Communication & EGX Sector Forecasts — Replication Code

Clean, minimal replication package for:
"Does Central Bank Communication Improve Stock-Market Return Forecasts?
Evidence from Egyptian Banks and Real Estate Sectors"

## Quick Start (with Thesis_Data.xlsx)

1. Place `Thesis_Data.xlsx` (from the Explorer Downloads) in this folder.
2. Install Python 3.11+ dependencies: `pip install numpy pandas scikit-learn gensim matplotlib openpyxl`
3. Verify all 3,100 saved predictions, 40 model scores, and 16 paired bootstrap CIs:
   ```bash
   python -m thesis_kit verify --excel Thesis_Data.xlsx
   ```
4. Or open `Thesis.ipynb` in Jupyter to view all summary tables interactively.

## Package Layout

- `thesis_kit/config.py` — Frozen model & Word2Vec/PCA hyperparameters
- `thesis_kit/data.py` — Data loaders (canonical workspace CSVs & standalone `Thesis_Data.xlsx`)
- `thesis_kit/features.py` — Past-only CBOW Word2Vec + training-cohort PCA (4 components)
- `thesis_kit/models.py` — Expanding-window chronological training (Ridge, Elastic Net, SVR, Random Forest)
- `thesis_kit/evaluate.py` — MAE, RMSE, R2_OS, directional accuracy, paired circular block bootstrap
- `thesis_kit/descriptive.py` — Chapter 4 descriptive tables (Tables 4.1–4.7)
- `thesis_kit/llm.py` — Optional loader for exploratory GPT-6 Luna follow-up scores
- `thesis_kit/cli.py` — Unified CLI (`verify`, `tables`, `train`, `followup`)
- `Thesis.ipynb` — Executed companion notebook
