"""Single CLI entry point for verifying, inspecting, or retraining thesis models."""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from .config import EXCEL_WORKBOOK, SAVED_RESULTS_DIR
from .data import load_excel_predictions, load_workspace_data
from .descriptive import chapter4_tables
from .evaluate import metric_tables, paired_tables, sector_contrast_tables, zero_gain_decomposition
from .llm import load_audit_same_estimator_controls, load_luna_scores
from .models import run_chronological_forecast


def cmd_verify(args: argparse.Namespace) -> None:
    """Verify exact numerical consistency of saved predictions, metrics, and Chapter 4 tables."""
    if args.excel:
        preds = load_excel_predictions(Path(args.excel))
        metrics = metric_tables(preds)
        paired = paired_tables(preds)
        print(f"Loaded {len(preds)} rows from {args.excel}")
        print(metrics[["case", "sector", "family", "variant", "test_events", "MAE_pp", "RMSE_pp"]].round(4).to_string(index=False))
        print("\nPaired text minus numerical (MAE pp, 95% circular block CI):")
        print(paired[["case", "sector", "family", "MAE_difference_pp", "MAE_difference_pp_low", "MAE_difference_pp_high"]].round(4).to_string(index=False))
        return

    saved_preds = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
    saved_metrics = pd.read_csv(SAVED_RESULTS_DIR / "metrics.csv")
    saved_paired = pd.read_csv(SAVED_RESULTS_DIR / "paired_text_differences.csv")

    recomp_metrics = metric_tables(saved_preds)
    recomp_paired = paired_tables(saved_preds)

    m_merged = saved_metrics.merge(recomp_metrics, on=["case", "sector", "horizon", "family", "variant"], suffixes=("_saved", "_recomp"))
    p_merged = saved_paired.merge(recomp_paired, on=["case", "sector", "horizon", "family"], suffixes=("_saved", "_recomp"))

    max_mae_err = float(np.max(np.abs(m_merged["MAE_pp_saved"] - m_merged["MAE_pp_recomp"])))
    max_rmse_err = float(np.max(np.abs(m_merged["RMSE_pp_saved"] - m_merged["RMSE_pp_recomp"])))
    max_pair_err = float(np.max(np.abs(p_merged["MAE_difference_pp_saved"] - p_merged["MAE_difference_pp_recomp"])))
    max_ci_err = float(np.max(np.abs(p_merged["MAE_difference_pp_low_saved"] - p_merged["MAE_difference_pp_low_recomp"])))

    assert max_mae_err < 1e-12 and max_rmse_err < 1e-12, (max_mae_err, max_rmse_err)
    assert max_pair_err < 1e-12 and max_ci_err < 1e-12, (max_pair_err, max_ci_err)

    data = load_workspace_data()
    t4 = chapter4_tables(data)
    print(f"OK: Verified {len(saved_preds)} predictions, {len(m_merged)} metric cells, {len(p_merged)} paired CIs, and {len(t4)} Chapter 4 tables.")
    print(f"Max replay errors -> MAE: {max_mae_err:.2e}, RMSE: {max_rmse_err:.2e}, Paired: {max_pair_err:.2e}, CI: {max_ci_err:.2e}")


def cmd_tables(_: argparse.Namespace) -> None:
    data = load_workspace_data()
    for name, df in chapter4_tables(data).items():
        print(f"\n=== {name} ===")
        print(df.round(4).to_string(index=False))


def cmd_train(args: argparse.Namespace) -> None:
    data = load_workspace_data()
    cases = [args.case] if args.case else ["expanded_legacy_live", "modern_live_only"]
    preds = run_chronological_forecast(data, cases=cases, include_text=not args.no_text, max_folds=args.max_folds)
    metrics = metric_tables(preds)
    print(metrics[["case", "sector", "family", "variant", "test_events", "MAE_pp", "RMSE_pp"]].round(4).to_string(index=False))
    if args.out:
        out_dir = Path(args.out)
        out_dir.mkdir(parents=True, exist_ok=True)
        preds.to_csv(out_dir / "predictions.csv", index=False)
        metrics.to_csv(out_dir / "metrics.csv", index=False)
        if not args.no_text:
            paired_tables(preds).to_csv(out_dir / "paired_text_differences.csv", index=False)
        print(f"Saved outputs to {out_dir}")


def cmd_followup(_: argparse.Namespace) -> None:
    print("=== 21 Nov 2026 Audit: Same-Estimator Controls (Track A Huber & ElasticNet) ===")
    audit = load_audit_same_estimator_controls()
    print(audit.round(4).to_string(index=False))
    try:
        scores = load_luna_scores()
        cols = [c for c in ("case", "sector", "task", "arm", "mae_pp", "rmse_pp", "brier") if c in scores.columns]
        print("\n=== Saved Exploratory GPT-6 Luna Scores ===")
        print(scores[cols].head(24).to_string(index=False))
    except FileNotFoundError:
        print("\n(Full outputs/luna_end_to_end_2026-11-20/scores.csv not bundled in standalone mode.)")


def cmd_diagnostics(args: argparse.Namespace) -> None:
    preds = load_excel_predictions(Path(args.excel)) if args.excel else pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
    print("=== Direct Paired Sector Contrasts (Real Estate minus Banks MAE gain, pp) ===")
    print(sector_contrast_tables(preds).round(4).to_string(index=False))
    print("\n=== Ridge Gain vs. Zero-Return Decomposition (pp) ===")
    print(zero_gain_decomposition(preds, family="ridge").round(4).to_string(index=False))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="thesis", description="CBE Thesis unified CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_verify = sub.add_parser("verify", help="Recompute and verify saved metrics, CIs, and tables")
    p_verify.add_argument("--excel", nargs="?", const=str(EXCEL_WORKBOOK), help="Verify from Thesis_Data.xlsx")
    p_verify.set_defaults(func=cmd_verify)

    p_tables = sub.add_parser("tables", help="Print Chapter 4 descriptive tables (4.1–4.7)")
    p_tables.set_defaults(func=cmd_tables)

    p_train = sub.add_parser("train", help="Re-run expanding-window chronological model training")
    p_train.add_argument("--case", choices=["expanded_legacy_live", "modern_live_only"], default=None)
    p_train.add_argument("--no-text", action="store_true", help="Skip Word2Vec/PCA text models")
    p_train.add_argument("--max-folds", type=int, default=None, help="Limit folds for quick smoke run")
    p_train.add_argument("--out", type=str, default=None, help="Optional directory to save CSVs")
    p_train.set_defaults(func=cmd_train)

    p_fup = sub.add_parser("followup", help="Show audited same-estimator controls & exploratory Luna summary")
    p_fup.set_defaults(func=cmd_followup)

    p_diag = sub.add_parser("diagnostics", help="Print direct sector contrasts & Ridge gain-vs-zero decomposition")
    p_diag.add_argument("--excel", nargs="?", const=str(EXCEL_WORKBOOK), help="Load predictions from Thesis_Data.xlsx")
    p_diag.set_defaults(func=cmd_diagnostics)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
