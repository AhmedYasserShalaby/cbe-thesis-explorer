"""Unified codebase for the CBE communication & EGX sector forecasting thesis."""

__version__ = "1.0.0"

from .config import MODEL_SETTINGS, TEXT_SETTINGS, BOOTSTRAP_SETTINGS
from .data import load_workspace_data, load_excel_predictions, load_splits
from .evaluate import score_predictions, metric_tables, paired_tables
from .descriptive import chapter4_tables
from .models import run_chronological_forecast

__all__ = [
    "__version__",
    "MODEL_SETTINGS",
    "TEXT_SETTINGS",
    "BOOTSTRAP_SETTINGS",
    "load_workspace_data",
    "load_excel_predictions",
    "load_splits",
    "score_predictions",
    "metric_tables",
    "paired_tables",
    "chapter4_tables",
    "run_chronological_forecast",
]
