"""Unified codebase for the CBE communication & EGX sector forecasting thesis."""

__version__ = "1.0.0"

from .config import MODEL_SETTINGS, TEXT_SETTINGS, BOOTSTRAP_SETTINGS
from .data import load_workspace_data, load_excel_predictions, load_splits
from .evaluate import score_predictions, metric_tables, paired_tables, sector_contrast_tables, zero_gain_decomposition
from .descriptive import chapter4_tables
from .llm import load_audit_same_estimator_controls
from .models import run_chronological_forecast

__all__ = [
    "__version__",
    "MODEL_SETTINGS",
    "TEXT_SETTINGS",
    "BOOTSTRAP_SETTINGS",
    "load_workspace_data",
    "load_excel_predictions",
    "load_splits",
    "score_predictions",
    "metric_tables",
    "paired_tables",
    "sector_contrast_tables",
    "zero_gain_decomposition",
    "load_audit_same_estimator_controls",
    "chapter4_tables",
    "run_chronological_forecast",
]
