"""Optional follow-up loader for the exploratory GPT-6 Luna LLM benchmark & 21 Nov audit."""
from __future__ import annotations

import json
from pathlib import Path
import pandas as pd

from .config import LUNA_DIR, ROOT

AUDIT_CHECKS_PATH = ROOT / "_archive" / "outputs" / "rag_pipeline_audit_2026-11-21" / "checks.json"

# Verified 21 Nov 2026 same-estimator audit controls (used as standalone fallback when _archive is absent)
_FALLBACK_SAME_ESTIMATOR = [
    {"case": "expanded_legacy_live", "sector": "banks", "estimator": "a_huber", "n": 119, "numbers_ridge_mae": 0.9671, "same_estimator_numbers_mae": 0.9857, "plus_dense_features_mae": 0.9842, "dense_gain_vs_same_estimator_pp": 0.0015, "ci_low": -0.0019, "ci_high": 0.0050},
    {"case": "expanded_legacy_live", "sector": "banks", "estimator": "a_elasticnet", "n": 119, "numbers_ridge_mae": 0.9671, "same_estimator_numbers_mae": 0.9532, "plus_dense_features_mae": 0.9542, "dense_gain_vs_same_estimator_pp": -0.0010, "ci_low": -0.0043, "ci_high": 0.0017},
    {"case": "expanded_legacy_live", "sector": "real_estate", "estimator": "a_huber", "n": 119, "numbers_ridge_mae": 1.5951, "same_estimator_numbers_mae": 1.5864, "plus_dense_features_mae": 1.5868, "dense_gain_vs_same_estimator_pp": -0.0004, "ci_low": -0.0023, "ci_high": 0.0018},
    {"case": "expanded_legacy_live", "sector": "real_estate", "estimator": "a_elasticnet", "n": 119, "numbers_ridge_mae": 1.5951, "same_estimator_numbers_mae": 1.5847, "plus_dense_features_mae": 1.5858, "dense_gain_vs_same_estimator_pp": -0.0011, "ci_low": -0.0022, "ci_high": -0.0001},
    {"case": "modern_live_only", "sector": "banks", "estimator": "a_huber", "n": 36, "numbers_ridge_mae": 0.9909, "same_estimator_numbers_mae": 1.0067, "plus_dense_features_mae": 1.0052, "dense_gain_vs_same_estimator_pp": 0.0015, "ci_low": -0.0033, "ci_high": 0.0062},
    {"case": "modern_live_only", "sector": "banks", "estimator": "a_elasticnet", "n": 36, "numbers_ridge_mae": 0.9909, "same_estimator_numbers_mae": 1.0266, "plus_dense_features_mae": 1.0262, "dense_gain_vs_same_estimator_pp": 0.0004, "ci_low": -0.0018, "ci_high": 0.0026},
    {"case": "modern_live_only", "sector": "real_estate", "estimator": "a_huber", "n": 36, "numbers_ridge_mae": 1.5100, "same_estimator_numbers_mae": 1.4665, "plus_dense_features_mae": 1.4661, "dense_gain_vs_same_estimator_pp": 0.0004, "ci_low": -0.0067, "ci_high": 0.0076},
    {"case": "modern_live_only", "sector": "real_estate", "estimator": "a_elasticnet", "n": 36, "numbers_ridge_mae": 1.5100, "same_estimator_numbers_mae": 1.4859, "plus_dense_features_mae": 1.4851, "dense_gain_vs_same_estimator_pp": 0.0008, "ci_low": -0.0275, "ci_high": 0.0243},
]


def load_luna_scores(luna_dir: Path = LUNA_DIR) -> pd.DataFrame:
    """Load saved exploratory GPT-6 Luna Track A & Track B benchmark scores."""
    path = luna_dir / "scores.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Exploratory Luna benchmark scores not found at {path}")
    return pd.read_csv(path)


def load_luna_intervals(luna_dir: Path = LUNA_DIR) -> pd.DataFrame:
    """Load saved paired bootstrap intervals for the GPT-6 Luna follow-up."""
    path = luna_dir / "intervals.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Exploratory Luna intervals not found at {path}")
    return pd.read_csv(path)


def load_audit_same_estimator_controls(checks_path: Path = AUDIT_CHECKS_PATH) -> pd.DataFrame:
    """Load 21 Nov 2026 same-estimator numerical controls for Track A Huber & ElasticNet."""
    if checks_path.is_file():
        raw = json.loads(checks_path.read_text())["matched_controls"]["matched_ablation"]
        rows = []
        for r in raw:
            rows.append(
                {
                    "case": r["case"],
                    "sector": r["sector"],
                    "estimator": r["estimator"],
                    "n": r["n"],
                    "numbers_ridge_mae": r["numbers_ridge_mae"],
                    "same_estimator_numbers_mae": r["same_estimator_numbers_mae"],
                    "plus_dense_features_mae": r["plus_dense_features_mae"],
                    "dense_gain_vs_same_estimator_pp": r["dense_gain_vs_same_estimator_pp"],
                    "ci_low": r["95_interval_pp"][0],
                    "ci_high": r["95_interval_pp"][1],
                }
            )
        return pd.DataFrame(rows)
    return pd.DataFrame(_FALLBACK_SAME_ESTIMATOR)
