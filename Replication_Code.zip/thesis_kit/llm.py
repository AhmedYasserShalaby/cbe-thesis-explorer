"""Optional follow-up loader for the exploratory GPT-6 Luna LLM benchmark."""
from __future__ import annotations

from pathlib import Path
import pandas as pd

from .config import LUNA_DIR


def load_luna_scores(luna_dir: Path = LUNA_DIR) -> pd.DataFrame:
    """Load saved exploratory GPT-6 Luna Track A & Track B benchmark scores."""
    path = luna_dir / "scores.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Exploratory Luna benchmark scores not found at {path}")
    return pd.read_csv(path)


def load_luna_intervals(luna_dir: Path = LUNA_DIR) -> pd.DataFrame:
    """Load saved paired bootstrap intervals for the GPT-6 Luna follow-up."""
    path = luna_dir / "intervals.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Exploratory Luna intervals not found at {path}")
    return pd.read_csv(path)
