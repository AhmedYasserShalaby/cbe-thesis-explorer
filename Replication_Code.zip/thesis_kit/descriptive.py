"""Chapter 4 descriptive statistics (Tables 4.1 through 4.7)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .data import WorkspaceData

START_DATE = "2007-01-03"
END_DATE = "2026-10-18"
INDEX_ORDER = ("banks", "real_estate", "egx30")
INDEX_NAMES = {"banks": "EGBANK", "real_estate": "EGREAL", "egx30": "EGX30"}


def summarize(values) -> dict[str, float | int]:
    arr = pd.to_numeric(values, errors="raise").dropna().to_numpy(float)
    return {
        "n": int(len(arr)),
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "sd": float(np.std(arr, ddof=1)),
        "min": float(np.min(arr)),
        "q1": float(np.quantile(arr, 0.25, method="linear")),
        "q3": float(np.quantile(arr, 0.75, method="linear")),
        "max": float(np.max(arr)),
    }


def chapter4_tables(data: WorkspaceData) -> dict[str, pd.DataFrame]:
    """Reproduce all seven Chapter 4 descriptive tables directly from canonical CSVs."""
    inv = data.corpus
    common = data.panel.loc[data.panel["in_common_event_cohort"]].copy()
    events = common.loc[common["sector"].eq("banks")].sort_values("event_date").copy()

    daily = data.daily.loc[data.daily["date"].between(START_DATE, END_DATE)].copy()
    closes = daily.loc[daily["eligible_close"]].copy()
    returns = daily.loc[
        daily["return_status"].eq("available") & daily["previous_session_date"].ge(START_DATE)
    ].copy()

    t1 = pd.DataFrame(
        [
            ["All original documents", len(inv), "Document inventory"],
            ["Policy-statement candidates", 174, "173 English and 1 Arabic only"],
            ["English policy candidates", 173, "Language-eligible inventory"],
            ["Arabic-only policy candidate", 1, "Excluded from English model"],
            ["Administrative notices", 2, "Excluded from policy model"],
            ["English candidates before sector history", 16, "Excluded before January 2007"],
            ["English candidates in shared 2011 reopening window", 2, "Excluded by event-window rules"],
            ["Common eligible English policy events", len(events), "99 legacy and 56 modern-live"],
            ["First-session sector outcomes", len(common), "155 Banks and 155 Real Estate"],
        ],
        columns=["Population or exclusion", "Count", "Meaning"],
    )

    t2 = pd.DataFrame(
        [
            {"Sample": label, **summarize(grp["reported_rate_change_bps"])}
            for label, grp in [
                ("Common cohort", events),
                ("Legacy", events.loc[events["legacy_regime"].eq(1)]),
                ("Modern-live", events.loc[events["legacy_regime"].eq(0)]),
            ]
        ]
    )

    annual_rows = []
    for year in range(2005, 2027):
        orig = inv.loc[inv["event_date"].str.startswith(str(year))]
        grp = events.loc[events["event_date"].str.startswith(str(year))]
        row: dict = {
            "Year": year,
            "Documents": len(orig),
            "Policy_candidates": int(orig["record_status"].eq("policy_statement_candidate").sum()),
            "English_policy_candidates": int(
                (orig["record_status"].eq("policy_statement_candidate") & orig["source_language"].eq("Official_English")).sum()
            ),
            "Eligible": len(grp),
        }
        for action in ("hike", "cut", "hold"):
            cnt = int(grp["policy_action"].eq(action).sum())
            row[f"{action}_n"] = cnt
            row[f"{action}_pct"] = 100.0 * cnt / len(grp) if len(grp) else None
        annual_rows.append(row)
    t3 = pd.DataFrame(annual_rows)

    t4 = pd.DataFrame(
        [{"Index": INDEX_NAMES[k], **summarize(closes.loc[closes["instrument"].eq(k), "close"])} for k in INDEX_ORDER]
    )
    t5 = pd.DataFrame(
        [
            {"Index": INDEX_NAMES[k], **summarize(returns.loc[returns["instrument"].eq(k), "daily_return_pct"])}
            for k in INDEX_ORDER
        ]
    )

    t6 = pd.DataFrame(
        [
            {
                "Sector": "Banks" if k == "banks" else "Real Estate",
                **summarize(s := common.loc[common["sector"].eq(k), "first_session_return_pct"]),
                "Positive": int(s.gt(0).sum()),
                "Negative": int(s.lt(0).sum()),
                "Zero": int(s.eq(0).sum()),
            }
            for k in ("banks", "real_estate")
        ]
    )

    t7 = pd.DataFrame(
        [
            ["Full history", "1 Feb 2007 to 24 Sep 2026", 155, 99, 56, 310, 36, 119, 238, "24 Nov 2011 to 24 Sep 2026"],
            ["Modern-live", "16 Jan 2020 to 24 Sep 2026", 56, 0, 56, 112, 20, 36, 72, "19 May 2022 to 24 Sep 2026"],
        ],
        columns=[
            "Sample",
            "Announcement dates",
            "Events",
            "Legacy",
            "Modern",
            "Sector outcomes",
            "Initial training events",
            "Evaluation events",
            "Evaluation sector outcomes",
            "Evaluation meeting dates",
        ],
    )

    return {f"table_4_{i}": tbl for i, tbl in enumerate([t1, t2, t3, t4, t5, t6, t7], start=1)}
