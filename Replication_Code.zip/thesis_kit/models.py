"""Expanding-window chronological training and prediction across both sectors."""
from __future__ import annotations

import os
from typing import Iterable

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNet, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

from .config import COHORT_CONFIG, MODEL_SETTINGS, NUMERIC_FEATURES, SECTORS, TARGET_COL
from .data import WorkspaceData, case_frame
from .features import PastOnlyTextEncoder


def make_estimator(family: str, settings: dict | None = None):
    params = (settings or MODEL_SETTINGS)[family]
    cls = {
        "ridge": Ridge,
        "elastic_net": ElasticNet,
        "rbf_svr": SVR,
        "random_forest": RandomForestRegressor,
    }[family]
    return cls(**params)


def run_chronological_forecast(
    data: WorkspaceData,
    cases: Iterable[str] = ("expanded_legacy_live", "modern_live_only"),
    families: Iterable[str] | None = None,
    include_text: bool = True,
    max_folds: int | None = None,
) -> pd.DataFrame:
    """Re-run exact expanding-window chronological forecasts on first-session returns."""
    for env_var in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ.setdefault(env_var, "1")

    selected_families = list(families) if families is not None else list(MODEL_SETTINGS.keys())
    encoder = PastOnlyTextEncoder(data.corpus) if include_text else None
    rows: list[dict] = []

    for case in cases:
        frame = case_frame(data.panel, case)
        numeric_cols = NUMERIC_FEATURES + COHORT_CONFIG[case]["extra_numeric"]
        plans = data.splits[case][:max_folds] if max_folds is not None else data.splits[case]

        for plan in plans:
            cutoff = plan["event_date"]
            train_ids = plan["training_doc_ids"]
            test_id = plan["doc_id"]
            train_df = frame.loc[frame["doc_id"].isin(train_ids)]
            test_df = frame.loc[frame["doc_id"].eq(test_id)]

            train_pcs, test_pcs = (
                encoder.fold_pcs(cutoff, train_ids, test_id) if encoder is not None else (None, None)
            )

            for sector in SECTORS:
                train_s = train_df.loc[train_df["sector"].eq(sector)].set_index("doc_id").loc[train_ids]
                test_s = test_df.loc[test_df["sector"].eq(sector)]

                x_num = train_s[numeric_cols].to_numpy(float)
                xt_num = test_s[numeric_cols].to_numpy(float)
                y = train_s[TARGET_COL].to_numpy(float)
                actual = float(test_s[TARGET_COL].iloc[0])
                hist_mean = float(y.mean())
                up, down = int((y > 0).sum()), int((y < 0).sum())

                common = {
                    "case": case,
                    "fold": plan["fold"],
                    "doc_id": test_id,
                    "event_date": cutoff,
                    "sector": sector,
                    "horizon": "first_session",
                    "sector_definition": test_s["sector_definition"].iloc[0],
                    "actual_pp": actual,
                    "historical_mean_pp": hist_mean,
                    "training_events": len(y),
                    "training_majority_sign": 1 if up >= down else -1,
                }
                rows.append({**common, "family": "historical_mean", "variant": "reference", "prediction_pp": hist_mean})
                rows.append({**common, "family": "zero_return", "variant": "reference", "prediction_pp": 0.0})

                variants = {"numerical": (x_num, xt_num)}
                if include_text and train_pcs is not None and test_pcs is not None:
                    variants["text_added"] = (
                        np.column_stack([x_num, train_pcs]),
                        np.column_stack([xt_num, test_pcs]),
                    )

                for variant, (x_raw, xt_raw) in variants.items():
                    scaler = StandardScaler().fit(x_raw)
                    x_sc, xt_sc = scaler.transform(x_raw), scaler.transform(xt_raw)
                    for family in selected_families:
                        model = make_estimator(family)
                        model.fit(x_sc, y)
                        pred = float(model.predict(xt_sc)[0])
                        rows.append({**common, "family": family, "variant": variant, "prediction_pp": pred})

    return pd.DataFrame(rows)
