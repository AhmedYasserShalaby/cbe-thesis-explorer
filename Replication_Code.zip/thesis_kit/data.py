"""Data loading and validation for workspace CSVs and standalone Thesis_Data.xlsx."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

import numpy as np
import pandas as pd

from .config import EXCEL_WORKBOOK, NUMERIC_FEATURES, PROCESSED_DIR, RATES_PATH, TARGET_COL


@dataclass(frozen=True)
class WorkspaceData:
    panel: pd.DataFrame
    corpus: pd.DataFrame
    daily: pd.DataFrame
    rates: pd.DataFrame
    splits: dict[str, list[dict]]


def _as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().isin(["true", "1"])


def load_splits(processed_dir: Path = PROCESSED_DIR) -> dict[str, list[dict]]:
    return json.loads((processed_dir / "chronological_splits.json").read_text(encoding="utf-8"))


def load_workspace_data(
    processed_dir: Path = PROCESSED_DIR,
    rates_path: Path = RATES_PATH,
) -> WorkspaceData:
    """Load the canonical first-session dataset (155 meetings, 310 outcomes)."""
    panel = pd.read_csv(processed_dir / "event_sector_modeling.csv", keep_default_na=False)
    corpus = pd.read_csv(processed_dir / "original_text_inventory.csv", keep_default_na=False)
    daily = pd.read_csv(processed_dir / "daily_prices.csv", keep_default_na=False)
    rates = pd.read_csv(rates_path)

    numeric_cols = NUMERIC_FEATURES + [TARGET_COL, "legacy_regime"]
    numeric_cols += [c for c in panel.columns if c.endswith("_sector_close") or c.endswith("_egx30_close")]
    for col in numeric_cols:
        if col in panel.columns:
            panel[col] = pd.to_numeric(panel[col].replace("", np.nan), errors="raise")

    for col in ("close", "previous_close", "daily_return_pct"):
        if col in daily.columns:
            daily[col] = pd.to_numeric(daily[col].replace("", np.nan), errors="raise")
    if "eligible_close" in daily.columns:
        daily["eligible_close"] = _as_bool(daily["eligible_close"])
    if "in_common_event_cohort" in panel.columns:
        panel["in_common_event_cohort"] = _as_bool(panel["in_common_event_cohort"])

    splits = load_splits(processed_dir)
    return WorkspaceData(panel=panel, corpus=corpus, daily=daily, rates=rates, splits=splits)


def case_frame(panel: pd.DataFrame, case: str) -> pd.DataFrame:
    """Filter panel to the common eligible cohort for a given evaluation sample."""
    frame = panel.loc[panel["in_common_event_cohort"]].copy()
    if case == "modern_live_only":
        frame = frame.loc[(frame["legacy_regime"] == 0) & (frame["pre_return_start_date"] >= "2020-01-02")]
    elif case != "expanded_legacy_live":
        raise ValueError(f"Unknown case: {case}")
    return frame.sort_values(["event_date", "doc_id", "sector"]).reset_index(drop=True)


def _read_xlsx_sheet_stdlib(xlsx_path: Path, sheet_name: str) -> pd.DataFrame:
    """Zero-dependency fallback XLSX sheet reader using stdlib zipfile + XML."""
    ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    rel_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    with zipfile.ZipFile(xlsx_path) as zf:
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
        rel_map = {r.attrib["Id"]: r.attrib["Target"] for r in rels}
        target = None
        for sheet in wb.findall(f".//{ns}sheet"):
            if sheet.attrib["name"] == sheet_name:
                target = rel_map[sheet.attrib[f"{rel_ns}id"]]
                break
        if target is None:
            raise ValueError(f"Sheet {sheet_name!r} not found in {xlsx_path}")
        shared: list[str] = []
        if "xl/sharedStrings.xml" in zf.namelist():
            sst = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            shared = ["".join(t.text or "" for t in si.findall(f".//{ns}t")) for si in sst.findall(f"{ns}si")]
        clean_target = target.lstrip("/")
        sheet_path = clean_target if clean_target.startswith("xl/") else f"xl/{clean_target}"
        root = ET.fromstring(zf.read(sheet_path))
        rows = []
        for row in root.findall(f".//{ns}sheetData/{ns}row"):
            vals = []
            for cell in row.findall(f"{ns}c"):
                t = cell.attrib.get("t")
                v = cell.find(f"{ns}v")
                if v is None or v.text is None:
                    vals.append(None)
                elif t == "s":
                    vals.append(shared[int(v.text)])
                elif t == "b":
                    vals.append(v.text == "1")
                else:
                    try:
                        vals.append(float(v.text))
                    except ValueError:
                        vals.append(v.text)
            rows.append(vals)
    return pd.DataFrame(rows[1:], columns=rows[0])


def load_excel_predictions(xlsx_path: Path = EXCEL_WORKBOOK) -> pd.DataFrame:
    """Load saved predictions from Thesis_Data.xlsx normalized to canonical columns."""
    try:
        raw = pd.read_excel(xlsx_path, sheet_name="Predictions", engine="openpyxl")
    except ImportError:
        raw = _read_xlsx_sheet_stdlib(xlsx_path, "Predictions")

    sample_map = {"Full history": "expanded_legacy_live", "2020 onwards": "modern_live_only"}
    sector_map = {"Banks": "banks", "Real Estate": "real_estate"}
    model_map = {
        "Historical mean": "historical_mean",
        "Zero return": "zero_return",
        "Ridge": "ridge",
        "Elastic Net": "elastic_net",
        "SVR": "rbf_svr",
        "Random Forest": "random_forest",
    }
    variant_map = {"Baseline": "reference", "No text": "numerical", "With text": "text_added"}

    df = pd.DataFrame(
        {
            "event_date": pd.to_datetime(raw["Date"]).dt.strftime("%Y-%m-%d")
            if not pd.api.types.is_numeric_dtype(raw["Date"])
            else (pd.Timestamp("1899-12-30") + pd.to_timedelta(raw["Date"], unit="D")).dt.strftime("%Y-%m-%d"),
            "case": raw["Sample"].map(sample_map),
            "sector": raw["Sector"].map(sector_map),
            "horizon": "first_session",
            "family": raw["Model"].map(model_map),
            "variant": raw["Inputs"].map(variant_map),
            "actual_pp": pd.to_numeric(raw["Actual"], errors="raise") * 100.0,
            "prediction_pp": pd.to_numeric(raw["Predicted"], errors="raise") * 100.0,
        }
    )
    # Attach expanding historical_mean_pp per (case, sector, event_date)
    means = (
        df.loc[df["family"].eq("historical_mean"), ["case", "sector", "event_date", "prediction_pp"]]
        .rename(columns={"prediction_pp": "historical_mean_pp"})
    )
    df = df.merge(means, on=["case", "sector", "event_date"], how="left")
    df["doc_id"] = df["event_date"]
    return df
