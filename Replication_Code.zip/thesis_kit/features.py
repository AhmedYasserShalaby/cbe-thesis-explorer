"""Past-only CBOW Word2Vec + training-cohort PCA text features (zero look-ahead)."""
from __future__ import annotations

import hashlib
import re
import unicodedata
from functools import cache

import numpy as np
import pandas as pd
from gensim.models import KeyedVectors, Word2Vec
from sklearn.decomposition import PCA

from .config import TEXT_SETTINGS


@cache
def check_word2vec_backend() -> None:
    """Reject the known Gensim backend that turns an exact -1 dot product into zero."""
    sentence = ["alpha", "beta"]
    probe = Word2Vec(vector_size=1, min_count=1, hs=1, negative=0, workers=1, window=1, sample=0)
    probe.build_vocab([sentence])
    probe.wv.vectors.fill(1.0)
    probe.syn1.fill(1.0)
    positive = probe.score([sentence], total_sentences=1)[0]
    probe.syn1.fill(-1.0)
    negative = probe.score([sentence], total_sentences=1)[0]
    # The two Huffman leaves have opposite codes. Reversing the weight swaps their scores.
    if not np.isclose(positive, negative, rtol=0.0, atol=2e-6):
        raise RuntimeError(
            "The Gensim Word2Vec backend failed the -1 dot-product check. "
            "Use the corrected runtime documented in the workspace README for text refits."
        )


def stable_hash(token: str) -> int:
    return int.from_bytes(hashlib.sha256(token.encode()).digest()[:8], "little")


def tokenize(text: str) -> list[str]:
    cleaned = unicodedata.normalize("NFKC", str(text)).lower().replace("\x00", "")
    return re.findall(r"[a-z]+(?:'[a-z]+)?|\d+(?:\.\d+)?|[^\w\s]", cleaned)


def sentence_tokens(text: str) -> list[list[str]]:
    chunks = re.split(r"(?<=[!?])\s+|(?<!\d)\.\s+|\n\s*\n", str(text))
    return [toks for chunk in chunks if len(toks := tokenize(chunk)) >= 2]


def language_history(corpus: pd.DataFrame, cutoff_date: str) -> pd.DataFrame:
    """All official English policy statements strictly before cutoff_date."""
    history = (
        corpus.loc[
            corpus["record_status"].eq("policy_statement_candidate")
            & corpus["source_language"].eq("Official_English")
            & corpus["event_date"].lt(cutoff_date)
        ]
        .sort_values(["event_date", "doc_id"])
        .copy()
    )
    if history.empty:
        raise ValueError(f"Empty English language history before {cutoff_date}")
    return history


def document_vector(wv: KeyedVectors, text: str) -> np.ndarray:
    toks = tokenize(text)
    known = [t for t in toks if t in wv]
    if not known:
        raise ValueError("Document has zero tokens in past vocabulary")
    return np.mean([wv[t] for t in known], axis=0).astype(np.float64)


class PastOnlyTextEncoder:
    """Fits CBOW Word2Vec on strictly prior English statements and projects via training-only PCA."""

    def __init__(self, corpus: pd.DataFrame, settings: dict | None = None):
        check_word2vec_backend()
        self.corpus = corpus
        self.lookup = corpus.set_index("doc_id")
        self.settings = settings or TEXT_SETTINGS
        self._wv_cache: dict[str, KeyedVectors] = {}

    def get_vectors(self, cutoff_date: str) -> KeyedVectors:
        if cutoff_date not in self._wv_cache:
            history = language_history(self.corpus, cutoff_date)
            sentences = [sent for text in history["statement_text"] for sent in sentence_tokens(text)]
            model = Word2Vec(sentences, hashfxn=stable_hash, **self.settings["word2vec"])
            self._wv_cache[cutoff_date] = model.wv
        return self._wv_cache[cutoff_date]

    def fold_pcs(self, cutoff_date: str, train_doc_ids: list[str], test_doc_id: str) -> tuple[np.ndarray, np.ndarray]:
        wv = self.get_vectors(cutoff_date)
        train_mat = np.stack([document_vector(wv, self.lookup.loc[d, "statement_text"]) for d in train_doc_ids])
        test_vec = document_vector(wv, self.lookup.loc[test_doc_id, "statement_text"]).reshape(1, -1)
        pca = PCA(**self.settings["pca"]).fit(train_mat)
        return pca.transform(train_mat), pca.transform(test_vec)
