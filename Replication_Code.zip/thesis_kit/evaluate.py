"""Forecast evaluation metrics and paired circular block-bootstrap intervals."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .config import BOOTSTRAP_SETTINGS


def direction_stats(actual, prediction) -> dict:
    a = np.asarray(actual, float)
    p = np.asarray(prediction, float)
    signs, guessed = np.sign(a), np.sign(p)
    up, down, nonzero = signs > 0, signs < 0, signs != 0
    correct = signs == guessed
    up_rec = float(correct[up].mean()) if up.any() else None
    down_rec = float(correct[down].mean()) if down.any() else None
    return {
        "actual_up": int(up.sum()),
        "actual_down": int(down.sum()),
        "actual_flat": int((signs == 0).sum()),
        "predicted_flat": int((guessed == 0).sum()),
        "direction_scored": int(nonzero.sum()),
        "direction_correct": int(correct[nonzero].sum()),
        "direction_accuracy": float(correct[nonzero].mean()) if nonzero.any() else None,
        "up_recall": up_rec,
        "down_recall": down_rec,
        "balanced_direction_accuracy": (up_rec + down_rec) / 2 if up_rec is not None and down_rec is not None else None,
    }


def score_predictions(actual, prediction, benchmark) -> dict:
    a, p, b = (np.asarray(x, float) for x in (actual, prediction, benchmark))
    err = p - a
    sse = float(np.dot(err, err))
    base_err = b - a
    denom = float(np.dot(base_err, base_err))
    return {
        "test_events": len(a),
        "MAE_pp": float(np.abs(err).mean()),
        "RMSE_pp": float(np.sqrt(np.mean(err**2))),
        "model_SSE_pp2": sse,
        "expanding_mean_SSE_pp2": denom,
        "R2_OS": 1.0 - sse / denom if denom != 0 else None,
        **direction_stats(a, p),
    }


def metric_tables(predictions: pd.DataFrame) -> pd.DataFrame:
    """Compute canonical MAE, RMSE, R2_OS and directional accuracy per model cell."""
    keys = ["case", "sector", "horizon", "family", "variant"]
    rows = []
    for group_keys, grp in predictions.groupby(keys, sort=True):
        rows.append(dict(zip(keys, group_keys)) | score_predictions(grp["actual_pp"], grp["prediction_pp"], grp["historical_mean_pp"]))
    return pd.DataFrame(rows)


def paired_bootstrap(actual, numerical, text, *, replicates=2000, block_length=5, seed=42) -> dict:
    """Circular moving-block bootstrap for text-added minus numerical-only error."""
    a, num, txt = (np.asarray(x, float) for x in (actual, numerical, text))
    num_sq, txt_sq = (num - a) ** 2, (txt - a) ** 2
    abs_delta = np.sqrt(txt_sq) - np.sqrt(num_sq)
    sq_delta = txt_sq - num_sq

    n = len(a)
    block = min(block_length, n)
    rng = np.random.default_rng(seed)
    starts = rng.integers(0, n, size=(replicates, int(np.ceil(n / block))))
    idx = ((starts[:, :, None] + np.arange(block)) % n).reshape(replicates, -1)[:, :n]

    boot_mae = abs_delta[idx].mean(axis=1)
    boot_mse = sq_delta[idx].mean(axis=1)
    boot_rmse = np.sqrt(txt_sq[idx].mean(axis=1)) - np.sqrt(num_sq[idx].mean(axis=1))

    out = {"test_events": n, "block_length": block, "replicates": replicates, "seed": seed}
    for label, est, boot in [
        ("MAE_difference_pp", abs_delta.mean(), boot_mae),
        ("MSE_difference_pp2", sq_delta.mean(), boot_mse),
        ("RMSE_difference_pp", np.sqrt(txt_sq.mean()) - np.sqrt(num_sq.mean()), boot_rmse),
    ]:
        lo, hi = np.quantile(boot, [0.025, 0.975])
        out[label] = float(est)
        out[f"{label}_low"] = float(lo)
        out[f"{label}_high"] = float(hi)
    return out


def paired_tables(predictions: pd.DataFrame, settings: dict | None = None) -> pd.DataFrame:
    """Compute paired text-minus-numerical differences and 95% circular block CIs."""
    cfg = settings or BOOTSTRAP_SETTINGS
    learned = predictions.loc[predictions["variant"].isin(["numerical", "text_added"])]
    keys = ["case", "sector", "horizon", "family"]
    rows = []
    for group_keys, grp in learned.groupby(keys, sort=True):
        num = grp.loc[grp["variant"].eq("numerical")].sort_values(["event_date", "doc_id"])
        txt = grp.loc[grp["variant"].eq("text_added")].sort_values(["event_date", "doc_id"])
        if not np.array_equal(num["event_date"].to_numpy(), txt["event_date"].to_numpy()):
            raise ValueError(f"Mismatched dates in paired comparison {group_keys}")
        rows.append(
            dict(zip(keys, group_keys))
            | paired_bootstrap(
                num["actual_pp"],
                num["prediction_pp"],
                txt["prediction_pp"],
                replicates=cfg["replicates"],
                block_length=cfg["block_length"],
                seed=cfg["seed"],
            )
        )
    return pd.DataFrame(rows)
