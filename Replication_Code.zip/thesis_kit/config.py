"""Paths and frozen canonical hyperparameters for the thesis pipeline."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

PROCESSED_DIR = ROOT / "04_data" / "processed" / "first_session_only_2026-10-28"
RATES_PATH = ROOT / "04_data" / "processed" / "policy_rate_levels_2026-10-27" / "policy_rate_provenance_v2.csv"
SAVED_RESULTS_DIR = ROOT / "06_results" / "first_session_only_2026-10-28" / "run_001"
EXCEL_WORKBOOK = ROOT / "10_submissions" / "2026-11-04_doctor_revision" / "Thesis_Data.xlsx"
LUNA_DIR = ROOT / "outputs" / "luna_end_to_end_2026-11-20"

SECTORS = ("banks", "real_estate")
TARGET_COL = "first_session_return_pct"
NUMERIC_FEATURES = [
    "pre_event_sector_return_pct",
    "pre_event_egx30_return_pct",
    "reported_rate_change_bps",
]

COHORT_CONFIG = {
    "expanded_legacy_live": {
        "initial_training_events": 36,
        "extra_numeric": ["legacy_regime"],
    },
    "modern_live_only": {
        "initial_training_events": 20,
        "extra_numeric": [],
    },
}

MODEL_SETTINGS = {
    "ridge": {"alpha": 1.0, "fit_intercept": True, "solver": "svd"},
    "elastic_net": {
        "alpha": 0.05,
        "l1_ratio": 0.5,
        "fit_intercept": True,
        "max_iter": 20000,
        "tol": 1e-7,
        "selection": "cyclic",
    },
    "rbf_svr": {
        "C": 1.0,
        "epsilon": 0.1,
        "kernel": "rbf",
        "gamma": "scale",
        "tol": 0.001,
        "cache_size": 128,
        "max_iter": -1,
    },
    "random_forest": {
        "n_estimators": 128,
        "max_depth": 3,
        "min_samples_leaf": 8,
        "max_features": 1.0,
        "bootstrap": True,
        "criterion": "squared_error",
        "random_state": 42,
        "n_jobs": 1,
    },
}

TEXT_SETTINGS = {
    "word2vec": {
        "vector_size": 100,
        "window": 5,
        "min_count": 2,
        "epochs": 30,
        "seed": 42,
        "workers": 1,
        "sg": 0,
        "hs": 0,
        "negative": 5,
        "ns_exponent": 0.75,
        "sample": 0.001,
        "alpha": 0.025,
        "min_alpha": 0.0001,
        "cbow_mean": 1,
        "sorted_vocab": 1,
        "batch_words": 10000,
        "shrink_windows": True,
    },
    "pca": {"n_components": 4, "svd_solver": "full", "whiten": False},
}

BOOTSTRAP_SETTINGS = {"replicates": 2000, "block_length": 5, "seed": 42}
