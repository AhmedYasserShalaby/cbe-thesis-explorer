"""Verification tests for the unified thesis_kit package."""
from __future__ import annotations

import unittest
import numpy as np
import pandas as pd

from thesis_kit.config import EXCEL_WORKBOOK, ROOT, SAVED_RESULTS_DIR
from thesis_kit.data import load_excel_predictions, load_workspace_data
from thesis_kit.descriptive import chapter4_tables
from thesis_kit.evaluate import metric_tables, paired_tables, sector_contrast_tables, zero_gain_decomposition
from thesis_kit.llm import load_audit_same_estimator_controls
from thesis_kit.models import run_chronological_forecast


class TestThesisKit(unittest.TestCase):
    def test_saved_results_exact_replay(self):
        preds = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
        saved_metrics = pd.read_csv(SAVED_RESULTS_DIR / "metrics.csv")
        saved_paired = pd.read_csv(SAVED_RESULTS_DIR / "paired_text_differences.csv")

        recomp_m = metric_tables(preds)
        recomp_p = paired_tables(preds)

        m = saved_metrics.merge(recomp_m, on=["case", "sector", "horizon", "family", "variant"], suffixes=("_s", "_r"))
        p = saved_paired.merge(recomp_p, on=["case", "sector", "horizon", "family"], suffixes=("_s", "_r"))

        self.assertEqual(len(m), 40)
        self.assertEqual(len(p), 16)
        self.assertTrue(np.allclose(m["MAE_pp_s"], m["MAE_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(m["RMSE_pp_s"], m["RMSE_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_s"], p["MAE_difference_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_low_s"], p["MAE_difference_pp_low_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_high_s"], p["MAE_difference_pp_high_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_high_s"], p["MAE_difference_pp_high_r"], atol=1e-12, rtol=0))

    def test_excel_workbook_matches_saved_metrics(self):
        excel_preds = load_excel_predictions(EXCEL_WORKBOOK)
        self.assertEqual(len(excel_preds), 3100)

        recomp_m = metric_tables(excel_preds)
        saved_metrics = pd.read_csv(SAVED_RESULTS_DIR / "metrics.csv")
        m = saved_metrics.merge(recomp_m, on=["case", "sector", "horizon", "family", "variant"], suffixes=("_s", "_r"))
        self.assertEqual(len(m), 40)
        self.assertTrue(np.allclose(m["MAE_pp_s"], m["MAE_pp_r"], atol=1e-10, rtol=0))
        self.assertTrue(np.allclose(m["RMSE_pp_s"], m["RMSE_pp_r"], atol=1e-10, rtol=0))

    def test_chapter4_tables_match_accepted_csvs(self):
        data = load_workspace_data()
        tables = chapter4_tables(data)
        ref_dir = ROOT / "10_submissions" / "2026-11-04_doctor_revision" / "Chapter4" / "tables"
        self.assertEqual(len(tables), 7)
        for name, df in tables.items():
            ref = pd.read_csv(ref_dir / f"{name}.csv")
            self.assertEqual(list(df.columns), list(ref.columns))
            self.assertEqual(len(df), len(ref))
            for col in df.columns:
                if pd.api.types.is_numeric_dtype(ref[col]):
                    self.assertTrue(
                        np.allclose(
                            pd.to_numeric(df[col], errors="coerce").fillna(-9999),
                            pd.to_numeric(ref[col], errors="coerce").fillna(-9999),
                            atol=1e-9,
                            rtol=1e-9,
                        ),
                        f"{name}.{col}",
                    )

    def test_chronological_refit_matches_saved_predictions(self):
        data = load_workspace_data()
        saved = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
        refit = run_chronological_forecast(data, cases=["modern_live_only"], include_text=True, max_folds=3)
        merged = refit.merge(
            saved,
            on=["case", "doc_id", "sector", "horizon", "family", "variant"],
            suffixes=("_refit", "_saved"),
        )
        self.assertEqual(len(merged), 3 * 2 * 10)
        num_only = merged.loc[merged["variant"].isin(["numerical", "reference"])]
        txt_only = merged.loc[merged["variant"].eq("text_added")]
        self.assertLess(float(np.max(np.abs(num_only["prediction_pp_refit"] - num_only["prediction_pp_saved"]))), 1e-12)
        self.assertLess(float(np.max(np.abs(txt_only["prediction_pp_refit"] - txt_only["prediction_pp_saved"]))), 1e-4)

    def test_sector_contrasts_and_zero_decomposition(self):
        preds = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
        sc = sector_contrast_tables(preds)
        self.assertEqual(len(sc), 8)
        # All 8 baseline Real Estate minus Banks 95% CIs include zero
        self.assertTrue(((sc["RE_minus_Banks_low"] <= 0.0) & (sc["RE_minus_Banks_high"] >= 0.0)).all())
        mod_rf = sc.loc[sc["case"].eq("modern_live_only") & sc["family"].eq("random_forest")].iloc[0]
        self.assertAlmostEqual(mod_rf["RE_minus_Banks_gain_pp"], 0.10129118245409832, places=10)

        dec = zero_gain_decomposition(preds, family="ridge")
        self.assertEqual(len(dec), 8)
        for _, r in dec.iterrows():
            self.assertEqual(r["n_right_win"] + r["n_right_tie"] + r["n_right_overshoot"] + r["n_wrong_or_flat"], r["test_events"])
            total = r["contrib_right_win_pp"] + r["contrib_right_tie_pp"] + r["contrib_right_overshoot_pp"] + r["contrib_wrong_or_flat_pp"]
            self.assertAlmostEqual(total, r["zero_MAE_pp"] - r["model_MAE_pp"], places=12)
            self.assertAlmostEqual(total, r["net_gain_vs_zero_pp"], places=12)

    def test_audit_same_estimator_controls(self):
        audit = load_audit_same_estimator_controls()
        self.assertEqual(len(audit), 8)
        mod_re_huber = audit.loc[audit["case"].eq("modern_live_only") & audit["sector"].eq("real_estate") & audit["estimator"].eq("a_huber")].iloc[0]
        self.assertAlmostEqual(mod_re_huber["dense_gain_vs_same_estimator_pp"], 0.0004056296977225309, places=4)


if __name__ == "__main__":
    unittest.main()
