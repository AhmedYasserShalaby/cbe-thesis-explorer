"""Verification tests for the unified thesis_kit package."""
from __future__ import annotations

import unittest
import numpy as np
import pandas as pd

from thesis_kit.config import EXCEL_WORKBOOK, ROOT, SAVED_RESULTS_DIR
from thesis_kit.data import load_excel_predictions, load_workspace_data
from thesis_kit.descriptive import chapter4_tables
from thesis_kit.evaluate import metric_tables, paired_tables
from thesis_kit.models import run_chronological_forecast


class TestThesisKit(unittest.TestCase):
    def test_saved_results_exact_replay(self):
        preds = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
        saved_metrics = pd.read_csv(SAVED_RESULTS_DIR / "metrics.csv")
        saved_paired = pd.read_csv(SAVED_RESULTS_DIR / "paired_text_differences.csv")

        recomp_m = metric_tables(preds)
        recomp_p = paired_tables(preds)

        m = saved_metrics.merge(recomp_m, on=["case", "sector", "horizon", "family", "variant"], suffixes=("_s", "_r"))
        p = saved_paired.merge(recomp_p, on=["case", "sector", "horizon", "family"], suffixes=("_s", "_r"))

        self.assertEqual(len(m), 40)
        self.assertEqual(len(p), 16)
        self.assertTrue(np.allclose(m["MAE_pp_s"], m["MAE_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(m["RMSE_pp_s"], m["RMSE_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_s"], p["MAE_difference_pp_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_low_s"], p["MAE_difference_pp_low_r"], atol=1e-12, rtol=0))
        self.assertTrue(np.allclose(p["MAE_difference_pp_high_s"], p["MAE_difference_pp_high_r"], atol=1e-12, rtol=0))

    def test_excel_workbook_matches_saved_metrics(self):
        excel_preds = load_excel_predictions(EXCEL_WORKBOOK)
        self.assertEqual(len(excel_preds), 3100)

        recomp_m = metric_tables(excel_preds)
        saved_metrics = pd.read_csv(SAVED_RESULTS_DIR / "metrics.csv")
        m = saved_metrics.merge(recomp_m, on=["case", "sector", "horizon", "family", "variant"], suffixes=("_s", "_r"))
        self.assertEqual(len(m), 40)
        self.assertTrue(np.allclose(m["MAE_pp_s"], m["MAE_pp_r"], atol=1e-10, rtol=0))
        self.assertTrue(np.allclose(m["RMSE_pp_s"], m["RMSE_pp_r"], atol=1e-10, rtol=0))

    def test_chapter4_tables_match_accepted_csvs(self):
        data = load_workspace_data()
        tables = chapter4_tables(data)
        ref_dir = ROOT / "10_submissions" / "2026-11-04_doctor_revision" / "Chapter4" / "tables"
        self.assertEqual(len(tables), 7)
        for name, df in tables.items():
            ref = pd.read_csv(ref_dir / f"{name}.csv")
            self.assertEqual(list(df.columns), list(ref.columns))
            self.assertEqual(len(df), len(ref))
            for col in df.columns:
                if pd.api.types.is_numeric_dtype(ref[col]):
                    self.assertTrue(
                        np.allclose(
                            pd.to_numeric(df[col], errors="coerce").fillna(-9999),
                            pd.to_numeric(ref[col], errors="coerce").fillna(-9999),
                            atol=1e-9,
                            rtol=1e-9,
                        ),
                        f"{name}.{col}",
                    )

    def test_chronological_refit_matches_saved_predictions(self):
        data = load_workspace_data()
        saved = pd.read_csv(SAVED_RESULTS_DIR / "predictions.csv")
        refit = run_chronological_forecast(data, cases=["modern_live_only"], include_text=True, max_folds=3)
        merged = refit.merge(
            saved,
            on=["case", "doc_id", "sector", "horizon", "family", "variant"],
            suffixes=("_refit", "_saved"),
        )
        self.assertEqual(len(merged), 3 * 2 * 10)
        num_only = merged.loc[merged["variant"].isin(["numerical", "reference"])]
        txt_only = merged.loc[merged["variant"].eq("text_added")]
        self.assertLess(float(np.max(np.abs(num_only["prediction_pp_refit"] - num_only["prediction_pp_saved"]))), 1e-12)
        self.assertLess(float(np.max(np.abs(txt_only["prediction_pp_refit"] - txt_only["prediction_pp_saved"]))), 1e-4)


if __name__ == "__main__":
    unittest.main()
